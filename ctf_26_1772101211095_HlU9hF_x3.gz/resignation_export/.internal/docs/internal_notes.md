# Internal Notes

## Q4 2024 Priorities

- Finalize client PoC for Apex Financial
- Migrate staging to new k8s cluster
- Rotate all service account credentials by Nov 15
- Ahmed to hand off scanner maintenance before departure

## Known Issues

- Scanner timeout on large networks (>500 hosts)
- Config loader doesn't handle nested env vars
- Need to add rate limiting to API endpoints
