# Developer Onboarding — CyberLeap Internal Tools

## Getting Started

1. Clone this repository
2. Install dependencies: `pip install -r requirements.txt`
3. Copy `config/example.yml` to `config/local.yml`
4. Run tests: `pytest tests/`

## Security Notes

- Never commit credentials to this repo
- All API keys must be stored in environment variables
- Use the vault for sensitive configuration
